﻿1. Title of Dataset: Density_and_RI_fitted
Data were collected in the Laboratory of Hydrodynamic Micromodels, Institute of Geophysica, Polish Academy of Sciences

2. Folder List: 

Folder contains data files for experimental sets:
set1_1.csv, set1_2.csv, set1_3.csv, set2_1.csv, set2_2.csv, set2_3.csv, set3_1.csv, set3_2.csv, set3_3.csv
	
3. Methodological information:
Description of methods used for collection/generation of data: 
Hyperbolic tangent function was fitted to measurement data stored in folder 'Density_and_RI_measured'.

4. Data-specific information:

*.csv files contain the following variables: 
variables stored in 3 columns: 
vertical position of measurement point interpolated [m], fitted density [kg m-3], fitted refractive index [nD].

Refractive index data were not fitted for set1_1, set1_2 and set1_2 due to 
insignifficant varioation of the index in a vertical profile.







