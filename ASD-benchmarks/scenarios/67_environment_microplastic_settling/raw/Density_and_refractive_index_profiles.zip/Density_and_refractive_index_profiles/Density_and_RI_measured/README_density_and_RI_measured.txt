﻿1. Title of Dataset: Density_and_RI_measured

Data were collected in the Laboratory of Hydrodynamic Micromodels, Institute of Geophysica, Polish Academy of Sciences

2. Folder List: 

Folder contains data files for experimental sets:
set1_1.csv, set1_2.csv, set1_3.csv, set2_1.csv, set2_2.csv, set2_3.csv, set3_1.csv, set3_2.csv, set3_3.csv

	
3. Methodological information:
Description of methods used for collection/generation of data: 
Vertical profile of desity and refractive index was measured. A series of samples spaced 5mm was taken and measured using oscillatory densimeter for density measurement and 
refractometer for refractive index. Detailed description presented in a paper linked to this dataset.

4. Data-specific information:

*.csv files contain the following variables: 
variables stored in 3 columns: vertical position of measurement point, zero corresponds to the position of visible interface [m] density [kg m-3], refractive index [nD].

Please note refractive index was not measured for set1_2






