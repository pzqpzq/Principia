function make_stage3_figures()
% Stage 3 - cross-validation figures. Mirrors the style of
% stage_0/make_stage0_figures.m, stage_1/make_stage1_figures.m,
% stage_2/make_stage2_figures.m. Outputs PNGs into
% revision_work/stage_3/figures/.

here = fileparts(mfilename('fullpath'));
root = fileparts(here);
figDir = fullfile(here, 'figures');
if ~exist(figDir, 'dir'), mkdir(figDir); end

S3 = load(fullfile(here, 'stage3_results.mat')); s3 = S3.results;
S2 = load(fullfile(root, 'stage_2', 'stage2_results.mat')); s2 = S2.results;

T = readtable(fullfile(root, 'stage_1', 'latency_with_achieved_bw_210.csv'));
qIdx  = T.qIdx(:); trial = T.trial(:);
b     = T.achieved_Mbps_server(:); L = T.latency_ms(:);
testMask = trial >= 4;

%% ============= FIGURE N: train vs test metrics =============
f = figure('Visible','off','Position',[100 100 950 380]);
tl = tiledlayout(f, 1, 3, 'Padding','compact','TileSpacing','compact');

nexttile(tl);
bar([s3.trainMetrics.MAE, s3.testMetrics.MAE]);
set(gca,'XTickLabel',{'Train (in-sample)','Test (out-of-sample)'});
title('MAE (ms)'); grid on; box on;

nexttile(tl);
bar([s3.trainMetrics.RMSE, s3.testMetrics.RMSE]);
set(gca,'XTickLabel',{'Train (in-sample)','Test (out-of-sample)'});
title('RMSE (ms)'); grid on; box on;

nexttile(tl);
bar([s3.trainMetrics.R2, s3.testMetrics.R2]);
set(gca,'XTickLabel',{'Train (in-sample)','Test (out-of-sample)'});
ylim([0.7 0.9]);
title('R^2'); grid on; box on;

title(tl, 'Stage 3: Train/Test Split (trial 1-3 vs 4-5) - In-Sample vs Out-of-Sample');
saveas(f, fullfile(figDir, 'figN_trainTest_metrics.png'));
close(f);

%% ============= FIGURE O: LOLO per-location R2 and MAE =============
lolo = s3.loloPerFold;
f = figure('Visible','off','Position',[100 100 950 550]);
tl = tiledlayout(f, 1, 2, 'Padding','compact','TileSpacing','compact');

nexttile(tl);
bb = bar(lolo.heldOut_qIdx, lolo.R2);
bb.FaceColor = [0.16 0.47 0.84];
yline(s2.R2, '--', sprintf('Stage 2 in-sample R^2=%.3f', s2.R2), 'Color',[0.92 0.41 0.20], 'LineWidth',1.5);
yline(s3.loloPooled.R2, ':', sprintf('LOLO pooled R^2=%.3f', s3.loloPooled.R2), 'Color',[0.11 0.69 0.48], 'LineWidth',1.5);
set(gca,'XTick',1:7,'XTickLabel',arrayfun(@(k)sprintf('Q%d',k),1:7,'UniformOutput',false));
title('R^2 per Held-Out Location'); ylim([0 1]); grid on; box on;

nexttile(tl);
bb2 = bar(lolo.heldOut_qIdx, lolo.MAE);
bb2.FaceColor = [0.16 0.47 0.84];
yline(s2.MAE, '--', sprintf('Stage 2 in-sample MAE=%.2f', s2.MAE), 'Color',[0.92 0.41 0.20], 'LineWidth',1.5);
set(gca,'XTick',1:7,'XTickLabel',arrayfun(@(k)sprintf('Q%d',k),1:7,'UniformOutput',false));
title('MAE (ms) per Held-Out Location'); grid on; box on;

title(tl, 'Stage 3: Leave-One-Location-Out - Per-Location Generalization');
saveas(f, fullfile(figDir, 'figO_lolo_perlocation.png'));
close(f);

%% ============= FIGURE P (NEW): predicted vs actual scatter, test set =============
pA = [s3.trainParams(1), s3.trainParams(2), s3.trainParams(3), s3.trainParams(4)];
gA = s3.trainGamma;
qTest = round(qIdx(testMask)); qTest(qTest<1)=1; qTest(qTest>7)=7;
predTest = pA(1) + pA(2).*b(testMask) + pA(3)./(pA(4) - b(testMask)) + gA(qTest)';
actualTest = L(testMask);

f = figure('Visible','off','Position',[100 100 700 700]);
scatter(actualTest, predTest, 36, [0.16 0.47 0.84], 'filled', 'MarkerFaceAlpha',0.7);
hold on;
lims = [0, max([actualTest; predTest])*1.05];
plot(lims, lims, 'k--', 'LineWidth', 1.3);
xlim(lims); ylim(lims); axis square;
xlabel('Ölçülen Gecikme (ms) - Test seti (trial 4-5)');
ylabel('Tahmin Edilen Gecikme (ms)');
title({'Stage 3: Tahmin vs Ölçüm (Test Seti, n=84)', sprintf('MAE=%.2f ms, RMSE=%.2f ms, R^2=%.3f', s3.testMetrics.MAE, s3.testMetrics.RMSE, s3.testMetrics.R2)});
grid on; box on;
saveas(f, fullfile(figDir, 'figP_predicted_vs_actual_test_NEW.png'));
close(f);

%% ============= FIGURE Q (NEW): headline R2 summary =============
f = figure('Visible','off','Position',[100 100 800 550]);
labels = {'Stage 2 in-sample (n=210)','Train/Test out-of-sample (n=84)','LOLO pooled out-of-sample (n=210)'};
vals = [s2.R2, s3.testMetrics.R2, s3.loloPooled.R2];
bb3 = bar(vals);
bb3.FaceColor = 'flat';
bb3.CData = [0.92 0.41 0.20; 0.16 0.47 0.84; 0.11 0.69 0.48];
set(gca, 'XTickLabel', labels);
ylim([0.75 0.86]);
ylabel('R^2');
title({'Stage 3: Cross-Validation Headline', 'In-Sample vs İki Bağımsız Out-of-Sample Yöntemi'});
grid on; box on;
for i=1:3
    text(i, vals(i)+0.003, sprintf('%.3f', vals(i)), 'HorizontalAlignment','center', 'FontWeight','bold');
end
saveas(f, fullfile(figDir, 'figQ_headline_r2_summary_NEW.png'));
close(f);

fprintf('Stage 3 figures written to: %s\n', figDir);
fprintf('  figN_trainTest_metrics.png\n');
fprintf('  figO_lolo_perlocation.png\n');
fprintf('  figP_predicted_vs_actual_test_NEW.png\n');
fprintf('  figQ_headline_r2_summary_NEW.png\n');

end
