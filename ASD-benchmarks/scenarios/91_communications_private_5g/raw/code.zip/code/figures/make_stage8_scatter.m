function stage8_make_scatter_svg()
% Builds a self-contained HTML report with two inline SVG scatter plots
% (pooled SD vs gamma_q, within-level SD vs gamma_q). Pure string
% generation - no MATLAB figure/graphics objects, no saveas/print, so
% none of the known hang risk from earlier stages applies.

here = fileparts(mfilename('fullpath'));
T = readtable(fullfile(here, 'stage8_gamma_vs_bandwidthSD.csv'));
load(fullfile(here, 'stage8_results.mat'), 'results');

svgA = makeScatterSVG(T.bandwidth_SD_pooled_Mbps, T.gamma_q, T.qIdx, ...
    'Pooled bandwidth SD (Mbps)', 'gamma_q (ms)', ...
    sprintf('(a) Pooled across all levels: r=%.3f, p=%.3f', results.r_pooled, results.p_pooled));

svgB = makeScatterSVG(T.bandwidth_SD_withinLevel_Mbps, T.gamma_q, T.qIdx, ...
    'Mean within-level bandwidth SD (Mbps)', 'gamma_q (ms)', ...
    sprintf('(b) Within-level (across trials): r=%.3f, p=%.3f', results.r_within, results.p_within));

html = sprintf([...
'<!DOCTYPE html><html><head><meta charset="utf-8">' ...
'<title>Stage 8 - gamma_q vs bandwidth SD</title>' ...
'<style>body{font-family:Arial,Helvetica,sans-serif;margin:24px;color:#222;}' ...
'.panels{display:flex;gap:24px;flex-wrap:wrap;} .panel{border:1px solid #ddd;border-radius:8px;padding:12px;}' ...
'h1{font-size:18px;} h2{font-size:14px;margin:4px 0 10px;} p{max-width:900px;}</style></head><body>' ...
'<h1>Stage 8 - Location offset (gamma_q) vs achieved-bandwidth variability</h1>' ...
'<p>n=7 locations. Panel (a) uses SD pooled across all trials AND all 6 target-bandwidth levels ' ...
'(as literally specified in the Stage 8 prompt); panel (b) uses SD across the 5 trials WITHIN each ' ...
'target level, averaged over the 6 levels, which isolates trial-to-trial throughput jitter at a fixed ' ...
'rate instead of the (location-independent) spread between target rates. See stage8_summary.txt for why ' ...
'(a) is confounded by design and (b) is the more defensible proxy for radio-channel instability.</p>' ...
'<div class="panels">' ...
'<div class="panel">%s</div>' ...
'<div class="panel">%s</div>' ...
'</div></body></html>'], svgA, svgB);

fid = fopen(fullfile(here, 'stage8_scatter_plots.html'), 'w');
fwrite(fid, html, 'char');
fclose(fid);
fprintf('Saved: stage8_scatter_plots.html\n');
end

function svg = makeScatterSVG(x, y, labels, xlab, ylab, titleStr)
    W = 460; H = 380;
    mL = 60; mR = 20; mT = 30; mB = 55;
    plotW = W - mL - mR; plotH = H - mT - mB;

    xr = max(x) - min(x); if xr == 0, xr = 1; end
    yr = max(y) - min(y); if yr == 0, yr = 1; end
    xmin = min(x) - 0.12*xr; xmax = max(x) + 0.12*xr;
    ymin = min(y) - 0.12*yr; ymax = max(y) + 0.12*yr;

    toPxX = @(v) mL + (v - xmin) / (xmax - xmin) * plotW;
    toPxY = @(v) mT + (1 - (v - ymin) / (ymax - ymin)) * plotH;

    parts = {};
    parts{end+1} = sprintf('<svg viewBox="0 0 %d %d" width="100%%" style="max-width:%dpx" xmlns="http://www.w3.org/2000/svg">', W, H, W);
    parts{end+1} = sprintf('<text x="%d" y="16" font-size="12" font-weight="bold" fill="#222">%s</text>', mL, titleStr);
    % axes
    parts{end+1} = sprintf('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#888"/>', mL, mT+plotH, mL+plotW, mT+plotH);
    parts{end+1} = sprintf('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#888"/>', mL, mT, mL, mT+plotH);
    % zero line for gamma if within range
    if ymin < 0 && ymax > 0
        y0 = toPxY(0);
        parts{end+1} = sprintf('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="#ccc" stroke-dasharray="3,3"/>', mL, y0, mL+plotW, y0);
    end
    % axis labels
    parts{end+1} = sprintf('<text x="%d" y="%d" font-size="11" fill="#444" text-anchor="middle">%s</text>', mL+plotW/2, H-8, xlab);
    parts{end+1} = sprintf('<text x="12" y="%.1f" font-size="11" fill="#444" text-anchor="middle" transform="rotate(-90 12 %.1f)">%s</text>', mT+plotH/2, mT+plotH/2, ylab);
    % tick labels (min/max)
    parts{end+1} = sprintf('<text x="%.1f" y="%d" font-size="9" fill="#666" text-anchor="start">%.2f</text>', mL, mT+plotH+16, min(x));
    parts{end+1} = sprintf('<text x="%.1f" y="%d" font-size="9" fill="#666" text-anchor="end">%.2f</text>', mL+plotW, mT+plotH+16, max(x));
    parts{end+1} = sprintf('<text x="%d" y="%.1f" font-size="9" fill="#666" text-anchor="end">%.2f</text>', mL-4, mT+4, max(y));
    parts{end+1} = sprintf('<text x="%d" y="%.1f" font-size="9" fill="#666" text-anchor="end">%.2f</text>', mL-4, mT+plotH, min(y));

    for i = 1:numel(x)
        px = toPxX(x(i)); py = toPxY(y(i));
        parts{end+1} = sprintf('<circle cx="%.1f" cy="%.1f" r="5" fill="#2563eb" fill-opacity="0.85"/>', px, py);
        parts{end+1} = sprintf('<text x="%.1f" y="%.1f" font-size="10" fill="#111">Q%d</text>', px+7, py-7, labels(i));
    end
    parts{end+1} = '</svg>';
    svg = strjoin(parts, '');
end
