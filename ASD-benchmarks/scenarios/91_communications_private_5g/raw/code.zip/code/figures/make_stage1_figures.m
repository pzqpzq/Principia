function make_stage1_figures()
% Stage 1 - comparison figures for the achieved-bandwidth extraction.
% NOTE: the paper's Figure 8 (bandwidth boxplot per location) comes from a
% SEPARATE TCP-only bandwidth benchmark (k*_bandwidthResult*.txt / bandwidthAnalysis.m),
% not from the UDP latency-test files parsed in Stage 1. The two are shown
% side-by-side for context only - they are not the same measurement.
% Outputs PNGs into revision_work/stage_1/figures/.

here = fileparts(mfilename('fullpath'));
figDir = fullfile(here, 'figures');
if ~exist(figDir, 'dir'), mkdir(figDir); end

A = readtable(fullfile(here, 'achieved_bandwidth_210.csv'));
bwLevels = [1 10 50 100 200 500];
nB = numel(bwLevels);
Q = 7;

%% ============= FIGURE 1: achieved vs target bandwidth, boxplot per level =============
f = figure('Visible','off','Position',[100 100 950 600]);
grp = A.B_target_Mbps;
boxplot(A.achieved_Mbps_server, grp, 'Labels', arrayfun(@(k)sprintf('%dM',k),bwLevels,'UniformOutput',false));
hold on;
% overlay target (nominal) bandwidth as reference markers
plot(1:nB, bwLevels, 'rd', 'MarkerSize', 10, 'MarkerFaceColor', 'r', 'DisplayName','Target (nominal)');
set(gca, 'YScale', 'log');
ylabel('Bandwidth (Mbps, log scale)'); xlabel('Target UDP bandwidth setting');
title('Stage 1: Achieved (received) vs Target Bandwidth, n=210 (new - no direct paper figure)');
legend('Location','northwest');
grid on; box on;
saveas(f, fullfile(figDir, 'fig1_achieved_vs_target_bandwidth.png'));
close(f);

%% ============= FIGURE 2: %deviation of achieved from target, per level =============
pctDev = 100*(A.achieved_Mbps_server - A.B_target_Mbps) ./ A.B_target_Mbps;
f = figure('Visible','off','Position',[100 100 900 550]);
boxplot(pctDev, grp, 'Labels', arrayfun(@(k)sprintf('%dM',k),bwLevels,'UniformOutput',false));
yline(0, 'k--');
ylabel('Achieved vs target deviation (%)'); xlabel('Target UDP bandwidth setting');
title('Stage 1: Systematic Achieved-Bandwidth Offset From Target (new)');
grid on; box on;
saveas(f, fullfile(figDir, 'fig2_achieved_target_deviation_pct.png'));
close(f);

%% ============= FIGURE 3: achieved bandwidth at 500M target, by location, vs paper Fig.8 (TCP test) =============
% Paper Figure 8 summary table (separate TCP bandwidth-only benchmark, for context):
paperQ    = 1:7;
paperMean = [652.8 646.6 635.1 644.9 641.2 636.1 655.3];
paperMin  = [644.2 636.8 619.4 624.8 619.7 617.0 639.7];
paperMax  = [660.1 653.9 650.7 657.4 660.8 661.8 663.3];

sel500 = A.B_target_Mbps == 500;
ourMeanByLoc = arrayfun(@(qi) mean(A.achieved_Mbps_server(sel500 & A.qIdx==qi)), 1:Q);
ourMinByLoc  = arrayfun(@(qi) min(A.achieved_Mbps_server(sel500 & A.qIdx==qi)), 1:Q);
ourMaxByLoc  = arrayfun(@(qi) max(A.achieved_Mbps_server(sel500 & A.qIdx==qi)), 1:Q);

f = figure('Visible','off','Position',[100 100 950 600]);
hold on;
errorbar(paperQ-0.12, paperMean, paperMean-paperMin, paperMax-paperMean, 'o', ...
    'Color',[0.75 0.1 0.1], 'MarkerFaceColor',[0.75 0.1 0.1], 'LineWidth',1.6, 'CapSize',8, ...
    'DisplayName','Paper Fig.8: TCP bandwidth-only test (unconstrained)');
errorbar(paperQ+0.12, ourMeanByLoc, ourMeanByLoc-ourMinByLoc, ourMaxByLoc-ourMeanByLoc, 's', ...
    'Color',[0.1 0.3 0.7], 'MarkerFaceColor',[0.1 0.3 0.7], 'LineWidth',1.6, 'CapSize',8, ...
    'DisplayName','Stage 1: UDP achieved bw @ 500 Mbps target');
set(gca,'XTick',1:7,'XTickLabel',arrayfun(@(k)sprintf('Q%d',k),1:7,'UniformOutput',false));
ylabel('Bandwidth (Mbps)'); xlabel('Location');
title({'Stage 1 vs Paper Fig. 8 - DIFFERENT TESTS, shown for context', ...
       'Paper: unconstrained TCP saturation test  |  Stage 1: UDP capped at 500 Mbps target'});
legend('Location','southoutside'); grid on; box on;
saveas(f, fullfile(figDir, 'fig3_bandwidth_by_location_vs_paperFig8.png'));
close(f);

fprintf('Stage 1 figures written to: %s\n', figDir);
fprintf('  fig1_achieved_vs_target_bandwidth.png\n');
fprintf('  fig2_achieved_target_deviation_pct.png\n');
fprintf('  fig3_bandwidth_by_location_vs_paperFig8.png\n');

end
