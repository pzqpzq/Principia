function make_stage2_figures()
% Stage 2 - comparison figures: published paper vs Stage 0 (target-b) vs
% Stage 2 (achieved-b). Mirrors the style of stage_0/make_stage0_figures.m
% and stage_1/make_stage1_figures.m. Outputs PNGs into
% revision_work/stage_2/figures/.

here = fileparts(mfilename('fullpath'));
root = fileparts(here);
figDir = fullfile(here, 'figures');
if ~exist(figDir, 'dir'), mkdir(figDir); end

S2 = load(fullfile(here, 'stage2_results.mat')); s2 = S2.results;
S0 = load(fullfile(root, 'stage_0', 'stage0_results.mat')); s0 = S0.results;

pub.L0 = 8.64; pub.beta = 0.0305; pub.theta = 486.84; pub.C = 611.39;
pub.gamma = [0 -0.47 -1.45 -1.31 0.78 -0.48 -1.68];
pub.MAE = 2.52; pub.RMSE = 3.13; pub.R2 = 0.842;

%% ============= FIGURE I: global params, published vs Stage0 vs Stage2 =============
paramNames = {'L0 (ms)','\beta (ms/Mbps)','\theta (ms\cdotMbps)','C (Mbps)'};
pubVals   = [pub.L0,   pub.beta,   pub.theta,   pub.C];
s0Vals    = [s0.L0,    s0.beta,    s0.theta,    s0.C];
s2Vals    = [s2.L0,    s2.beta,    s2.theta,    s2.C];

f = figure('Visible','off','Position',[100 100 900 650]);
tl = tiledlayout(f, 2, 2, 'Padding','compact','TileSpacing','compact');
for i = 1:4
    nexttile(tl);
    b = bar([pubVals(i), s0Vals(i), s2Vals(i)]);
    b.FaceColor = 'flat';
    b.CData = [0.92 0.41 0.20; 0.11 0.69 0.48; 0.16 0.47 0.84];
    set(gca, 'XTickLabel', {'Makale','Stage 0 (target-b)','Stage 2 (achieved-b)'});
    title(paramNames{i});
    grid on; box on;
end
title(tl, 'Stage 2: Global Parametreler - Makale vs Stage 0 (target-b) vs Stage 2 (achieved-b)');
saveas(f, fullfile(figDir, 'figI_global_params_comparison.png'));
close(f);

%% ============= FIGURE J: location offsets, 3-way =============
gammaS0 = s0.gamma;
gammaS2 = s2.gamma;

f = figure('Visible','off','Position',[100 100 900 550]);
x = 1:7;
b = bar(x, [pub.gamma; gammaS0; gammaS2]');
b(1).FaceColor = [0.92 0.41 0.20];
b(2).FaceColor = [0.11 0.69 0.48];
b(3).FaceColor = [0.16 0.47 0.84];
set(gca, 'XTick', 1:7, 'XTickLabel', arrayfun(@(k)sprintf('Q%d',k),1:7,'UniformOutput',false));
ylabel('\gamma_q (ms)');
title('Stage 2: Lokasyon Ofsetleri - Makale vs Stage 0 (target-b) vs Stage 2 (achieved-b)');
legend({'Makale','Stage 0 (target-b)','Stage 2 (achieved-b)'}, 'Location','southoutside','Orientation','horizontal');
grid on; box on;
saveas(f, fullfile(figDir, 'figJ_gamma_offsets_3way.png'));
close(f);

%% ============= FIGURE K: fit metrics, published vs Stage0 vs Stage2 =============
f = figure('Visible','off','Position',[100 100 950 380]);
tl = tiledlayout(f, 1, 3, 'Padding','compact','TileSpacing','compact');

nexttile(tl);
bar([pub.MAE, s0.MAE, s2.MAE]);
set(gca, 'XTickLabel', {'Makale','Stage 0','Stage 2'});
title('MAE (ms)'); grid on; box on;

nexttile(tl);
bar([pub.RMSE, s0.RMSE, s2.RMSE]);
set(gca, 'XTickLabel', {'Makale','Stage 0','Stage 2'});
title('RMSE (ms)'); grid on; box on;

nexttile(tl);
bar([pub.R2, s0.R2, s2.R2]);
set(gca, 'XTickLabel', {'Makale','Stage 0','Stage 2'});
ylim([0.8 0.86]);
title('R^2'); grid on; box on;

title(tl, 'Stage 2: Uyum Metrikleri Karşılaştırması');
saveas(f, fullfile(figDir, 'figK_metrics_comparison.png'));
close(f);

%% ============= FIGURE L (NEW): resnorm vs fixed-C, ridge (Stage0) vs minimum (Stage2) =============
P0 = readtable(fullfile(root, 'stage_0', 'stage0_C_profile.csv'));
P2 = readtable(fullfile(here, 'stage2_C_profile.csv'));

f = figure('Visible','off','Position',[100 100 950 600]);
semilogx(P0.C_fixed, P0.resnorm, '-o', 'Color',[0.92 0.41 0.20], 'LineWidth',2, 'MarkerFaceColor',[0.92 0.41 0.20]);
hold on;
semilogx(P2.C_fixed, P2.resnorm, '-s', 'Color',[0.16 0.47 0.84], 'LineWidth',2, 'MarkerFaceColor',[0.16 0.47 0.84]);
xlabel('C sabitlenmiş (Mbps, log)'); ylabel('resnorm');
title({'Stage 2: Resnorm vs Sabitlenmiş C', 'Sırt (Stage 0, target-b) vs Gerçek Minimum (Stage 2, achieved-b)'});
legend({'Stage 0 (target-b): sırt, sınırda en iyi','Stage 2 (achieved-b): gerçek minimum ~611'}, 'Location','north');
grid on; box on;
xline(s2.C, ':', sprintf('Stage2 C=%.2f', s2.C), 'LabelVerticalAlignment','bottom');
saveas(f, fullfile(figDir, 'figL_identifiability_ridge_vs_minimum_NEW.png'));
close(f);

%% ============= FIGURE M: multi-start convergence, Stage0 vs Stage2 =============
M0 = readtable(fullfile(root, 'stage_0', 'stage0_identifiability_scan.csv'));
M2 = readtable(fullfile(here, 'stage2_multistart_check.csv'));

f = figure('Visible','off','Position',[100 100 950 550]);
semilogx(M0.C0, M0.C_hat, '-o', 'Color',[0.92 0.41 0.20], 'LineWidth',2, 'MarkerFaceColor',[0.92 0.41 0.20]);
hold on;
semilogx(M2.C0_start, M2.C_hat, '-s', 'Color',[0.16 0.47 0.84], 'LineWidth',2, 'MarkerFaceColor',[0.16 0.47 0.84]);
xlabel('Başlangıç C_0 (Mbps, log)'); ylabel('Yakınsanan Ĉ (Mbps)');
title('Stage 2: Multi-Start Yakınsama - Stage 0 (sınıra yapışma) vs Stage 2 (gerçek optimum)');
legend({'Stage 0: her başlangıç \rightarrow C=501 (sınır)','Stage 2: her başlangıç \rightarrow C=611.39 (gerçek optimum)'}, 'Location','east');
grid on; box on;
ylim([480 630]);
saveas(f, fullfile(figDir, 'figM_multistart_convergence.png'));
close(f);

fprintf('Stage 2 figures written to: %s\n', figDir);
fprintf('  figI_global_params_comparison.png\n');
fprintf('  figJ_gamma_offsets_3way.png\n');
fprintf('  figK_metrics_comparison.png\n');
fprintf('  figL_identifiability_ridge_vs_minimum_NEW.png\n');
fprintf('  figM_multistart_convergence.png\n');

end
