function make_stage4_figures()
% Stage 4 - confidence interval figures. Mirrors the style of the
% stage_0..stage_3 figure scripts. Outputs PNGs into
% revision_work/stage_4/figures/.

here = fileparts(mfilename('fullpath'));
figDir = fullfile(here, 'figures');
if ~exist(figDir, 'dir'), mkdir(figDir); end

S4 = load(fullfile(here, 'stage4_results.mat')); s4 = S4.results;
boot = s4.bootParams; % 1000x10: L0 beta theta C gamma2..gamma7
pHat = s4.pHat;
names = s4.paramNames{1};

pub.L0 = 8.64; pub.beta = 0.0305; pub.theta = 486.84; pub.C = 611.39;
pub.gamma = [0 -0.47 -1.45 -1.31 0.78 -0.48 -1.68];

%% ============= FIGURE R: bootstrap histograms, L0/beta/theta/C =============
f = figure('Visible','off','Position',[100 100 950 700]);
tl = tiledlayout(f, 2, 2, 'Padding','compact','TileSpacing','compact');
labels = {'L0 (ms)','\beta (ms/Mbps)','\theta (ms\cdotMbps)','C (Mbps)'};
pubVals = [pub.L0, pub.beta, pub.theta, pub.C];
for i = 1:4
    nexttile(tl);
    histogram(boot(:,i), 40, 'FaceColor',[0.16 0.47 0.84], 'EdgeColor','none');
    hold on;
    xline(pHat(i), '-', 'Nokta tahmini', 'Color',[0.11 0.69 0.48], 'LineWidth',2);
    xline(pubVals(i), '--', 'Makale', 'Color',[0.92 0.41 0.20], 'LineWidth',2);
    xline(prctile(boot(:,i),2.5), ':', 'Color',[0.3 0.3 0.3]);
    xline(prctile(boot(:,i),97.5), ':', 'Color',[0.3 0.3 0.3]);
    title(labels{i}); grid on; box on;
end
title(tl, 'Stage 4: Bootstrap Dağılımları (B=1000) - Nokta Tahmini, Makale ve %95 CI');
saveas(f, fullfile(figDir, 'figR_bootstrap_histograms.png'));
close(f);

%% ============= FIGURE S: gamma_q bootstrap CI whiskers =============
gammaBootLo = [0, prctile(boot(:,5:10), 2.5, 1)];
gammaBootHi = [0, prctile(boot(:,5:10), 97.5, 1)];
gammaPoint  = [0, pHat(5:10)];

f = figure('Visible','off','Position',[100 100 900 550]);
x = 1:7;
errorbar(x, gammaPoint, gammaPoint-gammaBootLo, gammaBootHi-gammaPoint, 'o', ...
    'Color',[0.16 0.47 0.84], 'MarkerFaceColor',[0.16 0.47 0.84], 'LineWidth',1.8, 'CapSize',10);
hold on;
plot(x, pub.gamma, 'd', 'Color',[0.92 0.41 0.20], 'MarkerFaceColor',[0.92 0.41 0.20], 'MarkerSize',9);
set(gca,'XTick',1:7,'XTickLabel',arrayfun(@(k)sprintf('Q%d',k),1:7,'UniformOutput',false));
ylabel('\gamma_q (ms)');
legend({'Bootstrap nokta tahmini ±%95 CI','Makale'}, 'Location','southoutside','Orientation','horizontal');
title('Stage 4: Lokasyon Ofsetleri - Bootstrap %95 Güven Aralıkları');
grid on; box on;
saveas(f, fullfile(figDir, 'figS_gamma_bootstrap_CI.png'));
close(f);

%% ============= FIGURE T (NEW): CI width comparison, bootstrap vs asymptotic =============
ci_asym = s4.ci95_asymptotic;
bootWidth = prctile(boot,97.5,1) - prctile(boot,2.5,1);
asymWidth = (ci_asym(:,2) - ci_asym(:,1))';

f = figure('Visible','off','Position',[100 100 950 550]);
b1 = bar([bootWidth(3:4); asymWidth(3:4)]');
b1(1).FaceColor = [0.16 0.47 0.84];
b1(2).FaceColor = [0.92 0.41 0.20];
set(gca, 'YScale','log', 'XTickLabel', {'\theta (ms\cdotMbps)','C (Mbps)'});
ylabel('CI genişliği (log ölçek)');
legend({'Bootstrap %95 CI genişliği','Asymptotic (Jacobian) %95 CI genişliği'}, 'Location','northwest');
title({'Stage 4: CI Genişliği Karşılaştırması - \theta ve C', ...
       'Asymptotic CI ~14 kat daha geniş ve fiziksel olarak imkansız (negatif) değerler içeriyor'});
grid on; box on;
saveas(f, fullfile(figDir, 'figT_CI_width_comparison_NEW.png'));
close(f);

%% ============= FIGURE U (NEW): theta vs C bootstrap scatter (ridge visualization) =============
f = figure('Visible','off','Position',[100 100 900 700]);
scatter(boot(:,4), boot(:,3), 14, [0.16 0.47 0.84], 'filled', 'MarkerFaceAlpha', 0.35);
hold on;
plot(pHat(4), pHat(3), 'p', 'MarkerSize', 16, 'MarkerFaceColor',[0.11 0.69 0.48], 'MarkerEdgeColor','k');
plot(pub.C, pub.theta, 'd', 'MarkerSize', 12, 'MarkerFaceColor',[0.92 0.41 0.20], 'MarkerEdgeColor','k');
xlabel('C (Mbps)'); ylabel('\theta (ms\cdotMbps)');
title({'Stage 4: Bootstrap \theta vs C Dağılımı (n=1000)', ...
       'Güçlü pozitif korelasyon - Stage 0/2''deki sırt (ridge) bulgusunun bağımsız doğrulaması'});
legend({'Bootstrap replikaları','Nokta tahmini (achieved-b)','Makale'}, 'Location','northwest');
grid on; box on;
saveas(f, fullfile(figDir, 'figU_theta_vs_C_ridge_scatter_NEW.png'));
close(f);

fprintf('Stage 4 figures written to: %s\n', figDir);
fprintf('  figR_bootstrap_histograms.png\n');
fprintf('  figS_gamma_bootstrap_CI.png\n');
fprintf('  figT_CI_width_comparison_NEW.png\n');
fprintf('  figU_theta_vs_C_ridge_scatter_NEW.png\n');

end
