function make_stage5_figures()
% Stage 5 - jitter/loss/tail-latency figures. Mirrors the style of the
% stage_0..stage_4 figure scripts. Outputs PNGs into
% revision_work/stage_5/figures/.
%
% NOTE: tail_jitter_stats.m must be run first (produces stage5_results.mat
% in this same folder). This script only reads those saved results plus
% stage_1/achieved_bandwidth_210.csv (for the capacity-proximity scatter);
% it does not re-run any of the Stage 5 statistics.

here = fileparts(mfilename('fullpath'));
root = fileparts(here);
figDir = fullfile(here, 'figures');
if ~exist(figDir, 'dir'), mkdir(figDir); end

S5 = load(fullfile(here, 'stage5_results.mat')); s5 = S5.results;
byBw = s5.byBw;       % B_Mbps, jitter_mean_ms, jitter_sd_ms, loss_pct_mean, P99_est_mean_ms
cellT = s5.cellTable;  % qIdx, B_Mbps, ..., observed_max_mean_ms, observed_max_worst_ms

bwLevels = byBw.B_Mbps;
nB = numel(bwLevels);

%% ============= FIGURE V: jitter vs bandwidth (mean +/- sd) =============
f = figure('Visible','off','Position',[100 100 900 550]);
errorbar(1:nB, byBw.jitter_mean_ms, byBw.jitter_sd_ms, 'o-', ...
    'Color',[0.16 0.47 0.84], 'MarkerFaceColor',[0.16 0.47 0.84], 'LineWidth',1.8, 'CapSize',8);
set(gca,'XTick',1:nB,'XTickLabel',arrayfun(@(k)sprintf('%dM',k),bwLevels,'UniformOutput',false));
ylabel('Jitter (ms)'); xlabel('Target bandwidth');
title({'Stage 5: Jitter Bant Genişliğine Göre (7 lokasyon ortalaması)', ...
       'Kapasiteye yaklaştıkça artış BEKLENİRDİ - gözlenen yön TERSİ (Bulgu 1)'});
grid on; box on;
saveas(f, fullfile(figDir, 'figV_jitter_vs_bandwidth.png'));
close(f);

%% ============= FIGURE W: packet loss vs bandwidth =============
f = figure('Visible','off','Position',[100 100 900 550]);
bar(1:nB, byBw.loss_pct_mean, 'FaceColor',[0.92 0.41 0.20], 'EdgeColor','none');
set(gca,'XTick',1:nB,'XTickLabel',arrayfun(@(k)sprintf('%dM',k),bwLevels,'UniformOutput',false));
ylabel('Paket kaybı (%)'); xlabel('Target bandwidth');
title({'Stage 5: Ortalama Paket Kaybı Bant Genişliğine Göre', ...
       sprintf('Kapasiteye yakınlıkla korelasyon r=%.4f (queueing modeliyle tutarlı, Bulgu 2)', s5.corr_proximity_loss)});
grid on; box on;
saveas(f, fullfile(figDir, 'figW_packet_loss_vs_bandwidth.png'));
close(f);

%% ============= FIGURE X (EN ONEMLI): Gaussian P99 tahmini vs gozlemlenen gercek max =============
obsMaxByBw = arrayfun(@(b) mean(cellT.observed_max_mean_ms(cellT.B_Mbps==b)), bwLevels);

f = figure('Visible','off','Position',[100 100 950 600]);
x = 1:nB;
b1 = bar(x, [byBw.P99_est_mean_ms, obsMaxByBw]);
b1(1).FaceColor = [0.11 0.69 0.48];
b1(2).FaceColor = [0.75 0.10 0.10];
set(gca, 'YScale','log', 'XTick',1:nB,'XTickLabel',arrayfun(@(k)sprintf('%dM',k),bwLevels,'UniformOutput',false));
ylabel('Gecikme (ms, log ölçek)'); xlabel('Target bandwidth');
legend({'Gaussian P99 tahmini (avg+z\cdotstdev)','Gözlenen gerçek maksimum'}, 'Location','northwest');
title({'Stage 5: Gaussian P99 Tahmini vs Gerçek Gözlenen Maksimum (Bulgu 3, EN ÖNEMLİ)', ...
       'Tüm seviyelerde gerçek max, Gaussian P99 tahmininin ~11-27 katı - heavy-tailed dağılım'});
grid on; box on;
saveas(f, fullfile(figDir, 'figX_P99est_vs_observed_max.png'));
close(f);

%% ============= FIGURE Y: jitter/loss vs proximity to capacity (scatter) =============
A = readtable(fullfile(root, 'stage_1', 'achieved_bandwidth_210.csv'));
T5 = readtable(fullfile(here, 'stage5_trial_level.csv'));
C_ref = s5.C_ref;
proximity = A.achieved_Mbps_server ./ C_ref;

f = figure('Visible','off','Position',[100 100 950 700]);
tl = tiledlayout(f, 2, 1, 'Padding','compact', 'TileSpacing','compact');

nexttile(tl);
scatter(proximity, T5.jitter_ms, 14, [0.16 0.47 0.84], 'filled', 'MarkerFaceAlpha', 0.45);
xlabel('Kapasiteye yakınlık (b_{achieved}/C)'); ylabel('Jitter (ms)');
title(sprintf('Jitter vs kapasite yakınlığı (r=%.4f)', s5.corr_proximity_jitter));
grid on; box on;

nexttile(tl);
scatter(proximity, T5.loss_pct, 14, [0.92 0.41 0.20], 'filled', 'MarkerFaceAlpha', 0.45);
xlabel('Kapasiteye yakınlık (b_{achieved}/C)'); ylabel('Paket kaybı (%)');
title(sprintf('Paket kaybı vs kapasite yakınlığı (r=%.4f)', s5.corr_proximity_loss));
grid on; box on;

title(tl, 'Stage 5: Kapasite Yakınlığı ile Jitter/Loss İlişkisi (n=210 trial)');
saveas(f, fullfile(figDir, 'figY_proximity_scatter.png'));
close(f);

fprintf('Stage 5 figures written to: %s\n', figDir);
fprintf('  figV_jitter_vs_bandwidth.png\n');
fprintf('  figW_packet_loss_vs_bandwidth.png\n');
fprintf('  figX_P99est_vs_observed_max.png\n');
fprintf('  figY_proximity_scatter.png\n');

end
