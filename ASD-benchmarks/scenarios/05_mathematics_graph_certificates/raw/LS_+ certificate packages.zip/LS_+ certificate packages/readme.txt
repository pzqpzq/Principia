This folder contains two LS_+ certificate packages -- one for G_{6,1} (a 7-node, LS_+-rank 2 graph with a claw) and one for G_{17,1} (the smallest vertex-transitive graph with LS_+-rank 2).

Each subfolder contains the Y, U, V, and W matrices that make up the LS_+ certificate package of the corresponding graph, as well as the following files:

-- Edges.csv, which defines the graph in question by listing one edge per row.
-- Facet.csv, which gives the coefficients of the facet-inducing inequality of STAB(G) that is being violated by the certified point.

See also Code.zip in the dataset for MATLAB code which can be used to verify these certificates.