Description of files in this folder:

4MinimalWithCertificate.csv: Each row describes a graph for which we provide a LS_+^3 certificate package.
-- Column 1 is the "reference number" of the graph -- e.g. Column 1 says "44072" means the LS_+^3 certificate package for the graph in question is in folder "Cert_44072" inside LS_+^3 certificate packages.zip.
-- Column 2 gives the graph in graph6 format.
-- Columns 3 to 15 give the coefficients of the facet-inducing inequality of STAB(G) that is violated by the point described in the certificate package.

4Minimal.csv: This gives the complete list of 4-minimal graphs in our discovery, one per row. There are two cases for each row:
1) Column 2 is empty: The graph described in Column 1 is "certified 4-minimal"  (i.e., it is one of the graphs which appears in 4MinimalWithCertificate.csv.
2) Column 2 is non-empty: The graph described in Column 1 is "implied 4-minimal", due to being isomorphic to an edge subgraph of and sharing the same facet-inducing inequality with the graph described in Column 2, which is a certified 4-minimal graph.
