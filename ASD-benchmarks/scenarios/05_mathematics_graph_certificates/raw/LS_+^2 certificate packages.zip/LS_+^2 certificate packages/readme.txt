This folder contains nine LS_+^2 certificate packages -- eight for 3-minimal graphs G_{7,1} to G_{7,8}, and one for G_{17,2}, the smallest vertex-transitive graph with LS_+-rank 2.

Each subfolder contains the Y, U, V, and W matrices that make up the LS_+^2 certificate package of the corresponding graph, as well as the following files:

-- Edges.csv, which defines the graph in question by listing one edge per row.
-- Facet.csv, which gives the coefficients of the facet-inducing inequality of STAB(G) that is being violated by the certified point.

See also Code.zip in the dataset for MATLAB code which can be used to verify these certificates.
