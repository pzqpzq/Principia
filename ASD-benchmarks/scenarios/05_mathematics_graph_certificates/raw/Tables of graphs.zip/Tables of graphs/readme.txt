This folder contains four text files, each of which provides a list of graphs in graph6 format.

-- Figure_8.txt lists the 49 3-minimal graphs displayed in Figure 8.
-- Table_1.txt, Table_2.txt, and Table_3.txt correspond to the graphs listed in Tables 1, 2, and 3 in the manuscript.
