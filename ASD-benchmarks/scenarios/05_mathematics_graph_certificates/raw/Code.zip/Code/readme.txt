This folder contains MATLAB codes we wrote to verify all provided LS_+, LS_+^2, and LS_+^3-certificate packages. See the comments therein for more details on how to run these codes.
