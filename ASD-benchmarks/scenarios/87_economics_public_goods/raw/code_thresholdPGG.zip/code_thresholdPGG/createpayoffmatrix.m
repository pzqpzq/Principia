function [M1, M2, strategies1, strategies2] = createpayoffmatrix(endowments,productivities,threshold,reward,beta,gamma)

% [M1, M2, strategies1, strategies2] = createpayoffmatrix(endowments,productivities,threshold,reward)
% Creates the payoff matrices M1 and M2 for the two players, and the list
% of strategies for each player
% Inputs: 2-dim vector of endowments, 2-dim vector of productivities, 
% parameters for threshold and reward, beta(parameters for absolute contribution fairness) 
% and gamma(parameters for relative contribution fairness). 

strategies1 = 0:endowments(1); ns1=length(strategies1); 
strategies2 = 0:endowments(2); ns2=length(strategies2); 
M1=zeros(ns1,ns2); M2=zeros(ns1,ns2); 

for i1=1:ns1
    for i2=1:ns2
        M1(i1,i2) = endowments(1) - strategies1(i1) + reward*((strategies1(i1)*productivities(1)+strategies2(i2)*productivities(2))>= threshold)...
            -beta*abs(strategies1(i1)-strategies2(i2))/endowments(1)-gamma*abs(strategies1(i1)/endowments(1)-strategies2(i2)/endowments(2)); 
        M2(i1,i2) = endowments(2) - strategies2(i2) + reward*((strategies1(i1)*productivities(1)+strategies2(i2)*productivities(2))>= threshold)...
            -beta*abs(strategies1(i1)-strategies2(i2))/endowments(1)-gamma*abs(strategies1(i1)/endowments(1)-strategies2(i2)/endowments(2));
    end
end
end