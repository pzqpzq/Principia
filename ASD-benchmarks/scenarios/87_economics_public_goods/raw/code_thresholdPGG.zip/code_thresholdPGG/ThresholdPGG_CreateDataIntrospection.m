function ThresholdPGG_CreateDataIntrospection()

%% SETTING THE PARAMETERS %%
tmax= 10^7;
numberiterations = 1; 
gamerounds = 20; 
endowments = [24 24; 36 12; 24 24; 36 12; 36 12]; 
productivities = [1 1; 1 1; 3 1; 3 1; 1 3]; 
threshold = [24 24 48 60 36]; 
reward = 20; 
selectionstrength=1; % choose from {1,10,100}
beta=15; % parameter for absolute contribution fairness, choose from {0,5,10,15}
gamma=15; % parameter for relative contribution fairness, choose from {0,5,10,15}

tic

for treatment = 1:5   
    %% PREPARATIONS %%
    
    numberstrategies1 = endowments(treatment,1)+1; % number of pure strategies (actions)
    numberstrategies2 = endowments(treatment,2)+1; % number of pure strategies (actions)
    
    Distribution = zeros(numberstrategies2,numberstrategies1);
    conditional_P1 = zeros(1,endowments(treatment,2)+1);
    count_conditional_P1 = zeros(1,endowments(treatment,2)+1);
    conditional_P2 = zeros(1,endowments(treatment,1)+1);
    count_conditional_P2 = zeros(1,endowments(treatment,1)+1);
    
    % to compute success rates, effective rates and generated surpluses
    success_matrix = zeros(endowments(treatment,2)+1,endowments(treatment,1)+1); 
    effective_matrix = zeros(endowments(treatment,2)+1,endowments(treatment,1)+1); 
    generatedsurplus_matrix = zeros(endowments(treatment,2)+1,endowments(treatment,1)+1);
    for i1=1:endowments(treatment,1)+1
        for i2=1:endowments(treatment,2)+1
            success_matrix(endowments(treatment,2)+1-i2+1,i1) = productivities(treatment,1)*(i1-1) + productivities(treatment,2)*(i2-1) >= threshold(treatment);
            effective_matrix(endowments(treatment,2)+1-i2+1,i1) = productivities(treatment,1)*(i1-1) + productivities(treatment,2)*(i2-1) == threshold(treatment);
            if productivities(treatment,1)*(i1-1) + productivities(treatment,2)*(i2-1) >= threshold(treatment)
               generatedsurplus_matrix(endowments(treatment,2)+1-i2+1,i1) = (reward*2 - (i1-1 + i2-1)) / sum(endowments(treatment,:));
            else
               generatedsurplus_matrix(endowments(treatment,2)+1-i2+1,i1) =  - (i1-1 + i2-1) / sum(endowments(treatment,:));
            end
        end
    end
    success_matrices{treatment} = success_matrix;
    effective_matrices{treatment} = effective_matrix;
    generatedsurplus_matrices{treatment} = generatedsurplus_matrix;
    
    %% RUNNING SIMULATIONS 
    for iteration = 1:numberiterations
        %% GETTING THE PAYOFF MATRIX
         [payoffmatrix1, payoffmatrix2, ~, ~] = createpayoffmatrix(endowments(treatment,:),productivities(treatment,:),threshold(treatment),reward,beta,gamma);

        %% SELECT RANDOM INITIAL REACTIVE STRATEGIES
        initialstrategy1 = randi([0 endowments(treatment,1)],1,endowments(treatment,2)+2);% creates a random vector (c, c_0, c_1, …, c_i, …, c_e2) where c is the first-round action and ci is the contribution after the co-player contributes i
        initialstrategy2 = randi([0 endowments(treatment,2)],1,endowments(treatment,1)+2);% creates a random vector (c, c_0, c_1, …, c_i, …, c_e1) where c is the first-round action and ci is the contribution after the co-player contributes i
        
        %% SIMULATE PROCESS FOR GIVEN STRATEGIES
        [strategyvector1, strategyvector2, ~, ~] = SimulateIntrospection(initialstrategy1, initialstrategy2, payoffmatrix1, payoffmatrix2, selectionstrength, tmax, gamerounds);
        
        %% STORE QUANTITIES
        
        for k = 1:size(strategyvector1,2) %traversal: strategyvector1 and strategyvector2
            Distribution(numberstrategies2 - strategyvector2(k), strategyvector1(k)+1) = Distribution(numberstrategies2 - strategyvector2(k), strategyvector1(k)+1)+1;
        end 
        for t = 1: tmax %traversal strategyvector1 and strategyvector2 to select conditional contribution
            % for each time step: reacord gamerounds-1 conditional contributions each player 
            for r = 2:gamerounds
            % for player 1
            given_P2 = strategyvector2(r-1+(t-1)*gamerounds);  % player 2's action in the previous round
            conditional_P1(given_P2+1) = conditional_P1(given_P2+1) + strategyvector1(r+(t-1)*gamerounds);  % record conditional contribution of player 1
            count_conditional_P1(given_P2+1) = count_conditional_P1(given_P2+1) + 1; % the number of each "conditional contribution" pattern
            %for player 2
            given_P1 = strategyvector1(r-1+(t-1)*gamerounds);  % player 1's action in the previous round
            conditional_P2(given_P1+1) = conditional_P2(given_P1+1) + strategyvector2(r+(t-1)*gamerounds);  % record conditional contribution of player 2
            count_conditional_P2(given_P1+1) = count_conditional_P2(given_P1+1) + 1; % the number of each "conditional contribution" pattern
            end
        end     
  
    end
       

    %% COMPUTING THE FINAL OUTPUT
    StrategyDistributions{treatment} = Distribution/(numberiterations*gamerounds*tmax); 
    Reactive_P1{treatment} = conditional_P1./count_conditional_P1;
    Reactive_P2{treatment} = conditional_P2./count_conditional_P2;
    Count_conditional_P1{treatment} = count_conditional_P1;
    Count_conditional_P2{treatment} = count_conditional_P2;
    SuccessRates{treatment} = sum(success_matrices{treatment}.*StrategyDistributions{treatment},'all');
    EffectiveRates{treatment} = sum(effective_matrices{treatment}.*StrategyDistributions{treatment},'all');
    GeneratedSurplus{treatment} = sum(generatedsurplus_matrices{treatment}.*StrategyDistributions{treatment},'all');
end
SimTime=toc
filename = ['Data_TPGG_','g',num2str(gamerounds),'_s',num2str(selectionstrength),'_tmax',num2str(tmax),'_iteration',num2str(numberiterations),'_beta',num2str(beta),'_gamma',num2str(gamma)];
save(filename, 'StrategyDistributions','SuccessRates', 'EffectiveRates','GeneratedSurplus','gamerounds','selectionstrength', 'tmax', 'numberiterations','SimTime','beta','gamma','Reactive_P1','Reactive_P2','Count_conditional_P1','Count_conditional_P2');

end

