function [averagepayoff1, averagepayoff2, actions1, actions2] = SimulateGame(strategy1, strategy2, payoffmatrix1, payoffmatrix2, gamerounds)

% this function computes the average payoff over several rounds of a game
% for given conditional/reactive strategies of the 2 players

initialaction1 = strategy1(1);
initialaction2 = strategy2(1);

payoffs1 = zeros(1,gamerounds); % initiates a vector with payoffs for each round;
payoffs1(1) = payoffmatrix1(initialaction1+1,initialaction2+1); % the first round payoff

payoffs2 = zeros(1,gamerounds); 
payoffs2(1) = payoffmatrix2(initialaction1+1,initialaction2+1); 

actions1 = zeros(1,gamerounds); % vector of player 1 actions 
actions1(1) = strategy1(1);

actions2 = zeros(1,gamerounds); % vector of player 2 actions
actions2(1) = strategy2(1);

for t=2:gamerounds 
    actions1(t) = strategy1(actions2(t-1)+2); % player 1 action is their reaction to player 2's former action (we need to add +2 because the vector's component that corresponds to reacting to 0 is the 2nd)
    actions2(t) = strategy2(actions1(t-1)+2); 
    payoffs1(t) = payoffmatrix1(actions1(t)+1,actions2(t)+1);
    payoffs2(t) = payoffmatrix2(actions1(t)+1,actions2(t)+1);
end
 
averagepayoff1 = mean(payoffs1);
averagepayoff2 = mean(payoffs2);

end