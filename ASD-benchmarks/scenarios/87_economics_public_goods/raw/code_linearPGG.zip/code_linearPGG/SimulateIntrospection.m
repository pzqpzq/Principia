function [strategyvector1, strategyvector2, finalstrategyvector1, finalstrategyvector2] = SimulateIntrospection(initialstrategy1, initialstrategy2, payoffmatrix1, payoffmatrix2, selectionstrength, tmax, gamerounds)

%% Function SimulateIntrospection simulates the process of Introspection for tmax time steps for given initial reactive strategies

numberstrategies1 = size(payoffmatrix1,1); % number of pure strategies (actions)
numberstrategies2 = size(payoffmatrix1,2); % number of pure strategies (actions)

resident1 = initialstrategy1; 
resident2 = initialstrategy2;

% run the game for the initial strategies
[residentaveragepayoff1, residentaveragepayoff2, actions1, actions2] = SimulateGame(resident1, resident2, payoffmatrix1, payoffmatrix2, gamerounds);

currentactions1 = actions1;
currentactions2 = actions2;

%% INITIATING DATA %%

%% Strategy vector: vectors with actions for each round of the game 

strategyvector1 = zeros(1,gamerounds*tmax); 
strategyvector2 = zeros(1,gamerounds*tmax); 

strategyvector1(1:gamerounds) = currentactions1;
strategyvector2(1:gamerounds) = currentactions2;

%% Final strategy vector: vectors with actions for last round of the game 

finalstrategyvector1 = zeros(1,tmax); 
finalstrategyvector2 = zeros(1,tmax);

finalstrategyvector1(1) = currentactions1(end);
finalstrategyvector2(1) = currentactions2(end);

%% INTROSPECTION PROCESS %%

for t=2:tmax 
    
    % Player 1 updates
    if rand(1)<1/2
        alternativestrategy = randi([0 numberstrategies1-1],1,numberstrategies2+1);
        while alternativestrategy == resident1
            alternativestrategy = randi([0 numberstrategies1-1],1,numberstrategies2+1); 
        end
        [alternativeaveragepayoff1, alternativeaveragepayoff2, actions1, actions2] = SimulateGame(alternativestrategy, resident2, payoffmatrix1, payoffmatrix2, gamerounds);
        payoffdifference = alternativeaveragepayoff1 - residentaveragepayoff1; 
        switchingprobability = 1/(1+exp(-selectionstrength*payoffdifference));
        if rand(1) < switchingprobability
            resident1 = alternativestrategy;
            currentactions1 = actions1; 
            currentactions2 = actions2; 
            residentaveragepayoff1 = alternativeaveragepayoff1;
            residentaveragepayoff2 = alternativeaveragepayoff2;
        end
        
    % Player 2 updates   
    else
        alternativestrategy = randi([0 numberstrategies2-1],1,numberstrategies1+1);
        while alternativestrategy == resident2
            alternativestrategy = randi([0 numberstrategies2-1],1,numberstrategies1+1);
        end
        [alternativeaveragepayoff1, alternativeaveragepayoff2, actions1, actions2] = SimulateGame(resident1, alternativestrategy, payoffmatrix1, payoffmatrix2, gamerounds);
        payoffdifference = alternativeaveragepayoff2 - residentaveragepayoff2; 
        switchingprobability = 1/(1+exp(-selectionstrength*payoffdifference)); 
        if rand(1) < switchingprobability
            resident2 = alternativestrategy;
            currentactions2 = actions2;
            currentactions1 = actions1; 
            residentaveragepayoff2 = alternativeaveragepayoff2;
            residentaveragepayoff1 = alternativeaveragepayoff1; 

        end
    end
    
    % Storing actions and strategies
    strategyvector1(1+(t-1)*gamerounds : t*gamerounds) = currentactions1; 
    strategyvector2(1+(t-1)*gamerounds : t*gamerounds) = currentactions2;
    finalstrategyvector1(t) = currentactions1(end); 
    finalstrategyvector2(t) = currentactions2(end);
  
end

end